package Package1;

public class Car implements Comparable<Car>{
	
	/**
	* The class for the creation of the Car object and all methods associated with it. 
	*
	* CSC 1351 Programming Project No 1A
	7
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	private String make;
	private Integer year;
	private int price;
	
	/**
	* Constructor that sets the values of make, year, and price of a car object.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public Car(String Make, int Year, int Price) {
		//constructor that sets the values of make, year, and price
		this.make = Make;
		this.year = Year;
		this.price = Price;
	}
	
	/**
	* Returns the value of make.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public String getMake() {
		return make;
	}
	
	/**
	* Returns the value of year.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public int getYear() {
		return year;
	}
	
	/**
	* Returns the value of price.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public int getPrice() {
		return price;
	}
	
	/**
	* Compares two car objects based on make and, if the makes are equal, the year.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public int compareTo(Car other) {
		if (make.compareTo(other.make) !=0) {
			return make.compareTo(other.make);
		}
		else {
			return year.compareTo(other.year);
		}
	}
	
	/**
	* Returns the information of a car object in a specified format.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public String toString() {
		return "Make: " + make + ", Year : " + year + ", Price: " +
				price + ";";
	}

}
