package Package1;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.File;
import java.util.Scanner;

public class Prog01_aOrderedList {
	
	/**
	* Takes in formatted car information from an input file and transfers that information into
	* a new, output file in a more organized format. 
	*
	* CSC 1351 Programming Project No 1A
	7
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	/**
	* The main method, where the main code for the described above information occurs. 
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public static void main (String[] args) throws FileNotFoundException { 
		
		aOrderedList carList = new aOrderedList();
		
		Scanner inputFile = GetInputFile("Enter the input filename: ");
		String inputFileLine;
		while (inputFile.hasNextLine()) {
			inputFileLine = inputFile.nextLine();
			if (inputFileLine.substring(0,2).equals("A,")) {
				int firstComma = inputFileLine.indexOf(",");
				int secondComma = inputFileLine.indexOf(",", firstComma+1);
				int thirdComma = inputFileLine.indexOf(",", secondComma+1);
				Car carStore = new Car(inputFileLine.substring(firstComma+1, secondComma), Integer.parseInt(inputFileLine.substring(secondComma+1, thirdComma)), Integer.parseInt(inputFileLine.substring(thirdComma+1)));
				carList.add(carStore);
			}
			else if (inputFileLine.substring(0,2).equals("D,") && (int) inputFileLine.charAt(2) < 10) {
				int removeIndex = Integer.parseInt(inputFileLine.substring(2));
				carList.remove(removeIndex);
			}
			else {
				int firstComma = inputFileLine.indexOf(",");
				int secondComma = inputFileLine.indexOf(",", firstComma+1);
				Car carStore = new Car(inputFileLine.substring(firstComma+1, secondComma), Integer.parseInt(inputFileLine.substring(secondComma+1)), 0);
				for (int i=0; i < carList.size()-1; i++) {
					Car carSearch = (Car) carList.get(i); 
					if (carSearch != null && carStore.getMake().equals(carSearch.getMake()) && carStore.getYear()==carSearch.getYear()) {
						carList.remove(i);
					}
				}
			}
		}
		
		PrintWriter outputFile = GetOutputFile("Enter the output filename: ");
		outputFile.printf("Number of Cars: %s\n\n", carList.size());
		for (int i = 0; i < carList.size()-1; i++) {
			Car currentCar = (Car) carList.get(i);
			if (currentCar != null) {
				outputFile.printf("Make: %s\n", currentCar.getMake());
				outputFile.printf("Year: %s\n", currentCar.getYear());
				outputFile.printf("Price: %s\n\n", currentCar.getPrice());
			}
		}
		outputFile.close();
		System.out.println("The operation is complete! Please check your output file.");
	}
	
	/**
	* Obtains the input file from the user where the stored information will be read and used.
	* Also includes an exception check for if the file does not exist or is not accessible. 
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public static Scanner GetInputFile(String UserPrompt) throws FileNotFoundException {
		Scanner userInput = new Scanner(System.in);
		System.out.println(UserPrompt);
		String inputName = userInput.nextLine();
		try {
			File checkList = new File(inputName);
			Scanner checkScan = new Scanner (checkList);
			checkScan.close();
		}
		catch (Exception FileNotFoundException) {
			System.out.printf("File %s does not exist. Do you want to try again? <y,n>\n", inputName);
			String userChoice = userInput.nextLine();
			if (userChoice.equals("y") || userChoice.equals("Y")) {
				GetInputFile(UserPrompt);
			}
			else if (userChoice.equals("n") || userChoice.equals("N")) {
				System.out.println("Ending Program");
				userInput.close();
				throw FileNotFoundException;
			}
			else {
				System.out.println("Error: Unkown Command");
				userInput.close();
				throw FileNotFoundException;
			}
		}
		File readFile = new File(inputName);
		Scanner carsScan = new Scanner (readFile);
		return carsScan;
	}
	
	/**
	* Obtains the output file from the user where the stored information from the input file 
	* will be formated and placed.
	* Also includes an exception check for if the file does not exist or is not accessible. 
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public static PrintWriter GetOutputFile(String UserPrompt) throws FileNotFoundException {
		Scanner userOutput = new Scanner(System.in);
		System.out.println(UserPrompt);
		String outputName = userOutput.nextLine();
		try {
			File checkList = new File(outputName);
			Scanner checkScan = new Scanner (checkList);
			checkScan.close();
		}
		catch (Exception FileNotFoundException) {
			System.out.printf("File %s does not exist. Do you want to try again? <y,n>\n", outputName);
			String userChoice = userOutput.nextLine();
			if (userChoice.equals("y") || userChoice.equals("Y")) {
				GetOutputFile(UserPrompt);
			}
			else if (userChoice.equals("n") || userChoice.equals("N")) {
				System.out.println("Ending Program");
				userOutput.close();
				throw FileNotFoundException;
			}
			else {
				System.out.println("Error: Unkown Command");
				userOutput.close();
				throw FileNotFoundException;
			}
		}
		userOutput.close();
		PrintWriter carList = new PrintWriter(outputName);
		return carList;
	}
}

