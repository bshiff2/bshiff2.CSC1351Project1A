package Package1;

import java.util.Arrays;

public class aOrderedList {
	
	/**
	* The class for aOrderedList, which stores the complete array of the any Comparison objects. 
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
	private Comparable[] oList; //the ordered list
	private int listSize; //the size of the ordered list
	private int numObjects; //the number of objects in the ordered list
	private int curr = -1; //index of current element accessed via iterator methods, first element
						   //is in index 0
	
	
	/**
	* Constructor that creates an aOrderedList object.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS; 
		oList = new Comparable[SIZEINCREMENTS];
	}
	
	/**
	* Adds a new car object to the sorted array in the correct position to maintain sorted
	* order. If adding an object will exceed the current array size limit, it creates a new, 
	* larger array.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/

	 public void add(Comparable newObject) {
		 numObjects += 1;
		 if (numObjects > listSize) {
			 Comparable[] newList = Arrays.copyOf(oList, listSize + SIZEINCREMENTS);
			 oList = newList;
			 listSize = oList.length; 
		 }
		 for (int i = 0; i < listSize-1; i++) {
			 if (oList[i] == null) {
				 oList[i] = newObject;
				 i = listSize +1;
			}
			 else if (newObject.compareTo(oList[i]) == -1) {
				 for (int n = listSize - 2; n >= i; n--) {
					oList[n+1] = oList[n];
				 }
				 oList[i] = newObject;
				 i = listSize +1;
			}
			 else if (newObject.compareTo(oList[i]) == 0) {
				 for (int n = listSize - 2; n >= i; n--) {
					 oList[n] = oList[n+1];
				     oList[i+1] = newObject;
				     i = listSize +1;
				 }
			}
		  }
	  }
	 
	 /**
		* Returns the number of elements in oList.
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public int size() {
		 return numObjects;
	 }
	 
	 /**
		* Gets a specific object in oList based on it's index in oList. 
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public Comparable get(int index){
		 return oList[index];
	 }
	 
	 /**
		* Removes an instance of an object from oList and shifts oList accordingly.
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public void remove(int index) {
		 numObjects -= 1;
		 oList[index] = null;
		 for (int i = index + 1; i < listSize-1; i++) {
			 oList[i-1] = oList[i];
		 }
	 }
	 
	 /**
		* Returns the toString values of the list objects, separated by commas, and delimited
		* by brackets
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public String toString() {
		 String returnList = null;
		 for (int i = 0; i < listSize; i++) {
			 returnList = returnList + "[" + oList[i].toString() + "],";
		 }
		 return returnList;
	 }
	 
	 /**
		* Resets iterator parameters so that the “next” element is the first element in the
		* array, if any.
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public void reset() {
		 curr = -1;
	 }
	 
	 /**
		* Returns the next element in the iteration and increments the iterator parameters.
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public Comparable next() {
		 if (hasNext() == true) {
			 curr += 1;
			 return oList[curr]; 
		 }
		 else {
			 curr = 0;
			 return oList[curr]; 
		 }
	 }
	 
	 /**
		* Returns true if the iteration has more elements to iterate through and false if not. 
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public boolean hasNext() {
		 if (curr < listSize && oList[curr+1] != null) {
			 return true;
		 }
		 else {
			 return false;
		 }
	 }
	 
	 /**
		* Removes the last element returned by the next() method.  
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public void remove() {
		 remove (curr);
	 }

}
