package Package1;

import java.util.Arrays;
import java.util.Iterator;

public class aOrderedList {
	
	/**
	* The class for aOrderedList, which stores the complete array of the Car objects. 
	*
	* CSC 1351 Programming Project No 1A
	7
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	final int SIZEINCREMENTS = 20; //size of increments for increasing ordered list
	private Car[] oList; //the ordered list
	private int listSize; //the size of the ordered list
	private int numObjects; //the number of objects in the ordered list
	private int curr; //index of current element accessed via iterator methods
	
	/**
	* Constructor that creates an aOrderedList object.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/
	
	public aOrderedList() {
		numObjects = 0;
		listSize = SIZEINCREMENTS; 
		oList = new Car[SIZEINCREMENTS];
	}
	
	/**
	* Adds a new car object to the sorted array in the correct position to maintain sorted
	* order. If adding an object will exceed the current array size limit, it creates a new, 
	* larger array.
	*
	* CSC 1351 Programming Project No 1A
	* Section 2
	*
	* @author Bryce Shifflett
	* @since 3/17/2024
	*
	*/

	 public void add(Car newCar) {
		 if (oList[oList.length -1] != null) {
			 Car[] newList = Arrays.copyOf(oList, oList.length + SIZEINCREMENTS);
			 oList = newList;
		 }
		 for (int i = 0; i < oList.length; i++) {
			 if (oList[i] == null) {
				 oList[i] = newCar;
				 i = oList.length +1;
			}
			 else if (newCar.compareTo(oList[i]) == -1) {
				 for (int n = oList.length - 2; n >= i; n--) {
					oList[n+1] = oList[n];
				 }
				 oList[i] = newCar;
				 i = oList.length +1;
			}
			 else if (newCar.compareTo(oList[i]) == 0) {
				 for (int n = oList.length - 2; n > i; n--) {
						oList[n+1] = oList[n];
				 oList[i+1] = newCar;
				 }
			}
		  }
		 }
	 
	 /**
		* Returns the size(length) of oList.
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public int size() {
		 return oList.length;
	 }
	 
	 /**
		* Gets a specific car in oList based on it's index in oList. 
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public Car get(int index){
		 return oList[index];
	 }
	 
	 /**
		* Removes an instance of car from oList and shifts oList accordingly.
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public void remove(int index) {
		 oList[index] = null;
		 for (int i = index + 1; i < oList.length + 1; i++) {
			 oList[i-1] = oList[i];
		 }
	 }
	 
	 /**
		* Returns the toString values of the list objects, separated by commas, and delimited
		* by brackets
		*
		* CSC 1351 Programming Project No 1A
		* Section 2
		*
		* @author Bryce Shifflett
		* @since 3/17/2024
		*
		*/
	 
	 public String toString() {
		 String returnList = null;
		 for (int i = 0; i < oList.length; i++) {
			 returnList = returnList + "[" + oList[i].toString() + "],";
		 }
		 return returnList;
	 }

}
